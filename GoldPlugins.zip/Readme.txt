1. Распаковать (через ftp) содержимое архива на приставку в папку /data/GoldHEN/
2. Включить поддержку плагинов (GoldHEN-> Plugin Settings -> Enable Plugins Loader) и перезагрузить приставку